﻿/*
 * Created by SharpDevelop.
 * User: Usuario
 * Date: 22/01/2019
 * Time: 09:23 a. m.
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace asd
{
	/// <summary>
	/// Description of MainForm.
	/// </summary>
	public partial class MainForm : Form
	{
		
		Sintactico analisis;
		
		public MainForm()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
			
			analisis = new Sintactico();
		}
		
		void TextBox1TextChanged(object sender, EventArgs e)
		{
			
		}
		void TableLayoutPanel1Paint(object sender, PaintEventArgs e)
		{
			
		}
		void Button1Click(object sender, EventArgs e)
		{
			string copia;
			analisis = new Sintactico();
			analisis.setCadena(textBox1.Text);
			answerLabel.Text = analisis.Estado();
			
			copia = textBox1.Text;
			
			listBox1.Items.Clear();
			
			foreach(int a in analisis.erroresDeCodigo()){
				if(a > 0 && (a-1) <= copia.Length){
					listBox1.Items.Add("Error: " + copia[a-1] + "    Pos: " + a);
				}
			}
		}
	}
}
